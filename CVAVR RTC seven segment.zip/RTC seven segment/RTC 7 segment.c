#include <mega8535.h>
#include <delay.h>
#include <stdio.h>
// I2C Bus functions
#include <i2c.h>

// DS1307 Real Time Clock functions
#include <ds1307.h>

unsigned char hour,min,sec;
char angka[10]={0b11000000,0b11111001,0b10100100,0b10110000,0b10011001,0b10010010,0b10000010,0b11111000,0b10000000,0b10010000};
char angka1[10]={0b01000000,0b01111001,0b00100100,0b00110000,0b00011001,0b00010010,0b00000010,0b01111000,0b00000000,0b00010000};
char angka2[10]={0b11000000,0b11111001,0b01100100,0b01110000,0b01011001,0b01010010,0b01000010,0b11111000,0b01000000,0b01010000};
char angka3[10]={0b10000000,0b10111001,0b00100100,0b00110000,0b00011001,0b00010010,0b00000010,0b10111000,0b00000000,0b00010000};
char digit[4]={0b01111100,0b10111100,0b11011100,0b11101100};
int i;


void main(void)
{
i2c_init();
//rtc_set_time(21,28,0);//set hour,min,sec
//rtc_set_date(6,17,01,20);//set week_day,day,mont,year
rtc_init(0,0,0);
DDRA=0xFF;
DDRC=0b11111000;
while (1)
      {

      for(i=0;i<125;i++)
      {
      rtc_get_time(&hour,&min,&sec);// mengambil data waktu jam,menit,detik  
      PORTA=angka[hour/10];
      PORTC=digit[0];
      delay_ms(1);
      PORTA=angka[hour%10];
      PORTC=digit[1];
      delay_ms(1);
      PORTA=angka2[min/10];
      PORTC=digit[2];
      delay_ms(1);
      PORTA=angka[min%10];
      PORTC=digit[3];
      delay_ms(1);
      }
      
      for(i=0;i<125;i++)
      {
      rtc_get_time(&hour,&min,&sec);// mengambil data waktu jam,menit,detik  
      PORTA=angka[hour/10];
      PORTC=digit[0];
      delay_ms(1);
      PORTA=angka1[hour%10];
      PORTC=digit[1];
      delay_ms(1);
      PORTA=angka3[min/10];
      PORTC=digit[2];
      delay_ms(1);
      PORTA=angka[min%10];
      PORTC=digit[3];
      delay_ms(1);
      if(hour==05&&min==01)PORTC=0b11110000;
      }
      }
}
